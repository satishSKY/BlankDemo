// ReSharper disable UnknownCssClass
$.efc = {};
$.efc.server = "http://www.beedmondapp.com/wp-admin/admin-ajax.php";
$.efc.localImage = 'css/images/efc.png';
$.efc.loaded = false;
$.efc.phonegap = false;
$.efc.active = null;

function compare(el1, el2, index) {
    return el1[index] == el2[index] ? 0 : (el1[index] < el2[index] ? -1 : 1);
}

document.addEventListener("deviceready", function () {
    $.efc.phonegap = true;
});

$(document).on('pagebeforeshow', ":jqmData(role='page')", function () {
    if (!$.efc.loaded)
        return;
    
    var page = $(this);
    initPage(page);
});

function initPage(page) {
    switch (page.attr('id')) {
        case "beSafe":
            $.efc.active = $.efc.primarySafe;
            $.efc.activeCards = $.efc.safe;
            window.localStorage.setItem("active", JSON.stringify($.efc.active));
            window.localStorage.setItem("cards", JSON.stringify($.efc.activeCards));
            buildPrimaryPage(page);
            break;
        case "beHelpful":
            $.efc.active = $.efc.primaryHelpful;
            $.efc.activeCards = $.efc.helpful;
            window.localStorage.setItem("active", JSON.stringify($.efc.active));
            window.localStorage.setItem("cards", JSON.stringify($.efc.activeCards));
            buildPrimaryPage(page);
            break;
        case "beHealthy":
            $.efc.active = $.efc.primaryHealthy;
            $.efc.activeCards = $.efc.healthy;
            window.localStorage.setItem("active", JSON.stringify($.efc.active));
            window.localStorage.setItem("cards", JSON.stringify($.efc.activeCards));
            buildPrimaryPage(page);
            break;
        case "beSmart":
            $.efc.active = $.efc.primarySmart;
            $.efc.activeCards = $.efc.smart;
            window.localStorage.setItem("active", JSON.stringify($.efc.active));
            window.localStorage.setItem("cards", JSON.stringify($.efc.activeCards));
            buildPrimaryPage(page);
            break;
        case "video":
            if ($.efc.videoSrc == undefined) {
                $.efc.videoSrc = window.localStorage.getItem("videoSrc");
            }
            $('#video .content-container').empty();
            $('#video .content-container').oembed($.efc.videoSrc, { embedMethod: 'fill', maxHeight: 200, maxWidth: 300 });
            break;
        case "social":
            buildSocial(page);
            break;
        case "beConnected":
            buildConnected(page);
            break;
        case "map":
            buildMap(page);
            break;
        case "partners":
            buildPartner(page);
            break;
        case "contactBeEdmond":
            buildBeEdmond(page,"Contact");
            break;
        case "aboutBeEdmond":
            buildBeEdmond(page,"About");
            break;
        case "home":
            buildBeEdmond(page,"Home");
            break;
    }
}

function buildBeEdmond(page,title) {
    $.each($.efc.beEdmond, function(i, card) {
        if (card.post_title == title) {
            page.find('.content-container').html(card.post_content);
            if (card.image != "") {
                page.find('.primary-image img').attr("src", card.image);
            } else {
                page.find('.primary-image img').attr('src', $.efc.localImage);
            }

            if (title == "Home") {
                return;
            }

            var vidHtml = "";
            $.each(card.videos, function (j, video) {
                vidHtml += '<div class="vid-row"><a href="#" data-efc-src="' + video.src + '" class="oembed"><div class="overlay"></div><img src=' + video.thumbnail + ' height="60"/><p>' + video.title + '</p></a></div>';
            });
            if (vidHtml != "") {
                page.find('.content-container').prepend('<div data-role="collapsible" data-theme="f" class="primary-content" data-inset="false" data-iconpos="right" data-collapsed-icon="efc-collapsed" data-expanded-icon="efc-expanded" style="margin-top:-15px;"><h3>Video Selection</h3><div class="video-selection"></div></div>').trigger("create");
                page.find('.video-selection').html(vidHtml);
            }
        }
    });
}

function buildConnected(page) {
    page.find('.connected-list').empty();
    $.each($.efc.connected, function(i, card) {
        page.find('.connected-list').append($('<li data-sort-divider="' + card.post_title.substr(0, 1).toUpperCase() + '"><a href="#" data-efc-card="' + card.ID + '" class="connected-link"><img src="' + card.image + '" /><h3>' + card.post_title + '</h3><p>' + card.post_excerpt + '</p></a></li>'));
    });
    page.find('.connected-list').listview({
        autodividers: true,
        autodividersSelector: function (li) {
            return li.data('sort-divider');
        }
    });
    page.find('.connected-list').listview("refresh");
}

function buildPartner(page) {
    if ($.efc.active == undefined) {
        $.efc.active = JSON.parse(window.localStorage.getItem("active"));
    }
    page.find('.partner-call').attr('href', "tel:" + $.efc.active.phoneNumber);
    if($.efc.active.cellNumber == "") {
        page.find('.partner-sms').addClass("ui-disabled");
    } else {
        page.find('.partner-sms').attr('data-efc-number', $.efc.active.cellNumber);
        page.find('.partner-sms').removeClass("ui-disabled");
    }
    if($.efc.active.email == "") {
        page.find('.partner-email').addClass("ui-disabled");
    } else {
        page.find('.partner-email').attr('href', "mailto:" + $.efc.active.email);
        page.find('.partner-email').removeClass("ui-disabled");
    }

    if($.efc.active.website == "") {
        page.find('.partner-web').addClass("ui-disabled");
    } else {
        page.find('.partner-web').attr('data-efc-web', $.efc.active.website);
        page.find('.partner-web').removeClass("ui-disabled");
    }

    if ($.efc.active.image != "") {
        page.find('.partner-image img').load(function() {
            page.find('.partner-image').css('width', this.width);
        });
        page.find('.partner-image img').attr("src", $.efc.active.image);
    } else {
        page.find('.partner-image img').attr('src', 'css/images/efc.png');
    }

    page.find('.summary').html($.efc.active.post_excerpt);
    var vidHtml = "";
    $.each($.efc.active.videos, function (i, video) {
        vidHtml += '<div class="vid-row"><a href="#" data-efc-src="' + video.src + '" class="oembed"><div class="overlay"></div><img src=' + video.thumbnail + ' height="60"/><p>' + video.title + '</p></a></div>';
    });
    page.find('.video-selection').html(vidHtml);
}

function buildMap(page) {
    if ($.efc.active == undefined) {
        $.efc.active = JSON.parse(window.localStorage.getItem("active"));
    }
    if ($.efc.geocoder == undefined) {
        $.efc.markersArray = [];
        $.efc.geocoder = new window.google.maps.Geocoder();
        var latlng = new window.google.maps.LatLng(35.652484, -97.473836);
        var mapOptions = {
            zoom: 12,
            center: latlng,
            mapTypeId: window.google.maps.MapTypeId.ROADMAP
        };
        $.efc.map = new window.google.maps.Map(document.getElementById('map-canvas'), mapOptions);
    }
    codeAddress($.efc.active.address + ", " + $.efc.active.city + ", " + $.efc.active.state + " " + $.efc.active.zip);
    page.find('.map-address').html($.efc.active.address + "<br>" + $.efc.active.city + ", " + $.efc.active.state + " " + $.efc.active.zip);
}

function codeAddress(address) {
    if ($.efc.marker != undefined) {
        $.efc.marker.setMap(null);
    }
    $.efc.geocoder.geocode({ 'address': address }, function (results, status) {
        if (status == window.google.maps.GeocoderStatus.OK) {
            $.efc.map.setCenter(results[0].geometry.location);
            $.efc.marker = new window.google.maps.Marker({
                map: $.efc.map,
                position: results[0].geometry.location
            });
        } else {
            alert('Geocode was not successful for the following reason: ' + status);
        }
    });
}

function buildSocial(page) {
    if ($.efc.active == undefined) {
        $.efc.active = JSON.parse(window.localStorage.getItem("active"));
    }
    var facebook = "";
    var twitter = "";
    var instagram = "";
    if ($.efc.active.facebook != "")
        facebook = '<div><a href="#" data-efc-web="' + $.efc.active.facebook + '" class="social-link"><img src="css/images/facebook.png" /><div>Facebook</div></a></div>';
    if ($.efc.active.twitter != "")
        twitter = '<div><a href="#" data-efc-web="' + $.efc.active.twitter + '" class="social-link"><img src="css/images/twitter.png" /><div>Twitter</div></a></div>';
    if ($.efc.active.instagram != "")
        instagram = '<div><a href="#" data-efc-web="' + $.efc.active.instagram + '" class="social-link"><img src="css/images/instagram.png" /><div>Instagram</div></a></div>';
    page.find('.content-container').html('<div class="social-container">'+ facebook + twitter + instagram + '</div>');
}

function buildPrimaryPage(page) {
    if ($.efc.active == undefined) {
        $.efc.active = JSON.parse(window.localStorage.getItem("active"));
    }
    page.find('.primary-call').attr('href', "tel:" + $.efc.active.phoneNumber);
    
    if ($.efc.active.image != "") {
        page.find('.primary-image img').attr("src", $.efc.active.image);
    } else {
        page.find('.primary-image img').attr('src', $.efc.localImage);
    }

    if($.efc.active.cellNumber == "") {
        page.find('.primary-sms').addClass("ui-disabled");
    } else {
        page.find('.primary-sms').attr('data-efc-number', $.efc.active.cellNumber);
        page.find('.primary-sms').removeClass("ui-disabled");
    }
    
    if($.efc.active.email == "") {
        page.find('.primary-email').addClass("ui-disabled");
    } else {
        page.find('.primary-email').attr('href', "mailto:" + $.efc.active.email);
        page.find('.primary-email').removeClass("ui-disabled");
    }

    if($.efc.active.website == "") {
        page.find('.primary-web').addClass("ui-disabled");
    } else {
        page.find('.primary-web').attr('data-efc-web', $.efc.active.website);
        page.find('.primary-web').removeClass("ui-disabled");
    }

    page.find('.summary').html($.efc.active.post_excerpt);
    var vidHtml = "";
    $.each($.efc.active.videos, function (i, video) {
        vidHtml += '<div class="vid-row"><a href="#" data-efc-src="' + video.src + '" class="oembed"><div class="overlay"></div><img src=' + video.thumbnail + ' height="60"/><p>' + video.title + '</p></a></div>';
    });
    page.find('.video-selection').html(vidHtml);
    var cardHtml = "";
    $.each($.efc.activeCards, function (i, card) {
        cardHtml += '<div class="card-row"><a href="#" data-efc-card="' + card.ID + '" class="card-link"><img src="' + card.image + '" width="100" /><p>' + card.post_title + '</p></a></div>';
    });
    page.find('.partners').html(cardHtml);
}

$(document).ready(function ($) {
    $(document).on('click', '.oembed', function () {
        $.efc.videoSrc = $(this).data('efc-src');
        window.localStorage.setItem("videoSrc", $.efc.videoSrc);
        $.mobile.changePage($('#video'), { transition: "none" });
    });

    $(document).on('click', '.card-link', function () {
        var cardId = $(this).data('efc-card');
        $.each($.efc.activeCards, function (i, card) {
            if (card.ID == cardId) {
                $.efc.active = card;
            }
        });
        window.localStorage.setItem("active", JSON.stringify($.efc.active));
        $.mobile.changePage($('#partners'), { transition: "none" });
    });

    $(document).on('click', '.connected-link', function () {
        var cardId = $(this).data('efc-card');
        $.each($.efc.connected, function (i, card) {
            if (card.ID == cardId) {
                $.efc.active = card;
            }
        });
        window.localStorage.setItem("active", JSON.stringify($.efc.active));
        $.mobile.changePage($('#partners'), { transition: "none" });
    });


    $(document).on('click', '.efc-email', function () {

    });

    $(document).on('click', '.efc-map', function () {

    });

    $(document).on('click', '.efc-social', function () {

    });

    $(document).on('click', '.primary-web, .partner-web, .social-link', function () {
        var webUrl = $(this).data('efc-web');
        if(webUrl.indexOf("http") < 0) {
            tmp = webUrl.split("//");
            if(tmp.length == 1) {
                webUrl = "http://" + tmp[0];
            } else {
                webUrl = "http://" + tmp[1];
            }
        }
        window.open(webUrl, '_blank', 'location=yes');
    });

    var lastUpdate = window.localStorage.getItem('lastUpdate');
    if (lastUpdate) {
        var upd = new Date(Date.parse(lastUpdate));
        upd.setHours ( upd.getHours() + 6 );
        var today = new Date();

        if (upd.getTime() < today.getTime()) {
            getUpdate();
        } else {
            var valid = true;
            var connected = window.localStorage.getItem('beConnected');
            if (connected && connected != "[]") {
                $.efc.connected = JSON.parse(connected);
            } else {
                valid = false;
            }
            var healthy = window.localStorage.getItem('beHealthy');
            if (healthy && healthy != "[]") {
                $.efc.healthy = JSON.parse(healthy);
            } else {
                valid = false;
            }
            var helpful = window.localStorage.getItem('beHelpful');
            if (helpful && helpful != "[]") {
                $.efc.helpful = JSON.parse(helpful);
            } else {
                valid = false;
            }
            var primary = window.localStorage.getItem('primary');
            if (primary && primary != "[]") {
                $.efc.primary = JSON.parse(primary);
            } else {
                valid = false;
            }
            var safe = window.localStorage.getItem('beSafe');
            if (safe && safe != "[]") {
                $.efc.safe = JSON.parse(safe);
            } else {
                valid = false;
            }
            var smart = window.localStorage.getItem('beSmart');
            if (smart && smart != "[]") {
                $.efc.smart = JSON.parse(smart);
            } else {
                valid = false;
            }

            var beEdmond = window.localStorage.getItem('beEdmond');
            if (beEdmond && beEdmond != "[]") {
                $.efc.beEdmond = JSON.parse(beEdmond);
            } else {
                valid = false;
            }

            if (!valid) {
                getUpdate();
            } else {
                var primhealthy = window.localStorage.getItem("primaryHealthy");
                if(primhealthy)
                    $.efc.primaryHealthy = JSON.parse(primhealthy);

                var primHelpful = window.localStorage.getItem("primaryHelpful");
                if(primHelpful) 
                    $.efc.primaryHelpful = JSON.parse(primHelpful);

                var primSafe = window.localStorage.getItem("primarySafe");
                if(primSafe)
                    $.efc.primarySafe = JSON.parse(primSafe);

                var primSmart = window.localStorage.getItem("primarySmart");
                if(primSmart)
                    $.efc.primarySmart = JSON.parse(primSmart);
                
                if ($('.ui-page-active').attr('id') == "intro") {
                    $.mobile.changePage($('#home'), { transition: "none" });
                }
            }
            $.efc.loaded = true;
            initPage($('.ui-page-active'));
        }
    } else {
        getUpdate();
    }

    function getUpdate() {
        $.ajax({
            url: $.efc.server,
            data: {
                'action': 'do_ajax',
                'fn': 'get_cards'
            },
            dataType: "json",
            success: function (data) {
                data.connected.sort(function (el1, el2) {
                    return compare(el1, el2, "post_title");
                });
                data.healthy.sort(function (el1, el2) {
                    return compare(el1, el2, "post_title");
                });
                data.helpful.sort(function (el1, el2) {
                    return compare(el1, el2, "post_title");
                });
                data.safe.sort(function (el1, el2) {
                    return compare(el1, el2, "post_title");
                });
                data.smart.sort(function (el1, el2) {
                    return compare(el1, el2, "post_title");
                });
                window.localStorage.setItem("lastUpdate", new Date());
                window.localStorage.setItem("beEdmond", JSON.stringify(data.beEdmond));
                window.localStorage.setItem("beConnected", JSON.stringify(data.connected));
                window.localStorage.setItem("beHealthy", JSON.stringify(data.healthy));
                window.localStorage.setItem("beHelpful", JSON.stringify(data.helpful));
                window.localStorage.setItem("primary", JSON.stringify(data.primary));
                window.localStorage.setItem("beSafe", JSON.stringify(data.safe));
                window.localStorage.setItem("beSmart", JSON.stringify(data.smart));
                $.efc.connected = data.connected;
                $.efc.healthy = data.healthy;
                $.efc.helpful = data.helpful;
                $.efc.primary = data.primary;
                $.efc.safe = data.safe;
                $.efc.smart = data.smart;
                $.efc.beEdmond = data.beEdmond;

                $.each($.efc.primary, function(index, card) {
                    switch(card.category) {
                        case "healthy":
                            window.localStorage.setItem("primaryHealthy", JSON.stringify(card));
                            $.efc.primaryHealthy = card;
                            break;
                        case "helpful":
                            window.localStorage.setItem("primaryHelpful", JSON.stringify(card));
                            $.efc.primaryHelpful = card;
                            break;
                        case "safe":
                            window.localStorage.setItem("primarySafe", JSON.stringify(card));
                            $.efc.primarySafe = card;
                            break;
                        case "smart":
                            window.localStorage.setItem("primarySmart", JSON.stringify(card));
                            $.efc.primarySmart = card;
                            break;
                    }
                });
                $.efc.loaded = true;
                initPage($('.ui-page-active'));
            },
            error: function (errorThrown) {
                alert('error');
                console.log(errorThrown);
            }
        });
    }
    $('#shareForm').submit(function () {
        if ($('#send-to').val() == "") {
            alert("Please enter an email address");
            return false;
        }

        data = {
            'action': 'do_ajax',
            'fn': 'share_app',
            'email': $(this).find('#send-to').val(),
            'message': $('.shareMessage').html().replace(/<div>/g, "").replace(/<\/div>/g, "")
        };
        $.ajax({
            url: $.efc.server,
            data: data,
            dataType: 'JSON',
            success: function (data) {
                console.log(data)
                $.mobile.changePage($('#home'), { transition: "fade" });
            },
            error: function (e) {
                alert("There was an error submitting your request.  Please try again later.");
            }
        });
        return false;
    });
});
// ReSharper restore UnknownCssClass
