$(document).on('pagebeforeshow', "#sendSMS", function () {
    if (!$.efc.loaded)
        return;

    var page = $(this);
    page.find('#cellNumber').val($.efc.cellNumber);
    page.find('#cellNumber').attr('readonly','readonly');
});

function show_about_page() {
    $.mobile.changePage($("#aboutBeEdmond"), { transition: "none" });
}
function show_contact_page() {
    $.mobile.changePage($("#contactBeEdmond"), { transition: "none" });
}

document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
    navigator.splashscreen.hide();
}

$(document).ready(function ($) {
    var smsSendingPlugin = cordova.require('cordova/plugin/smssendingplugin');

    $(document).on('click', '.about-efc', function () {
        window.plugins.openOptionsMenu.openMenu();
    });

    $(document).on('click', '.primary-sms, .partner-sms', function () {
        $.efc.cellNumber = $(this).data('efc-number');
        $.mobile.changePage($("#sendSMS"), { transition: "none" });
    });

    $(document).on('click', '.submit-sms', function () {
        smsSendingPlugin.send ($('#cellNumber').val(), $('#cellMessage').val(), function() {
            navigator.notification.alert("Message sent :-)", null, "Be Edmond", "OK");
            $.mobile.back();
          }, function() {
            navigator.notification.alert("Message not sent :s", null, "Be Edmond", "OK");
          });
    });
});
