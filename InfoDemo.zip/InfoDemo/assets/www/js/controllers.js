angular.module('starter.controllers', [])

.controller('HomeCtrl', function($scope) {
	
})

